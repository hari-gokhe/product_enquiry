package RequestDTO;

import java.time.LocalDate;

public class ProductEnquiryRequestDTO {
	private String clientName;
	private String clientMobile;
	private LocalDate dateOfEnquiry;
	private Integer productId;

	public ProductEnquiryRequestDTO(String clientName, String clientMobile, LocalDate dateOfEnquiry,
			Integer productId) {
		super();
		this.clientName = clientName;
		this.clientMobile = clientMobile;
		this.dateOfEnquiry = dateOfEnquiry;
		this.productId = productId;
	}

	public ProductEnquiryRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientMobile() {
		return clientMobile;
	}

	public void setClientMobile(String clientMobile) {
		this.clientMobile = clientMobile;
	}

	public LocalDate getDateOfEnquiry() {
		return dateOfEnquiry;
	}

	public void setDateOfEnquiry(LocalDate dateOfEnquiry) {
		this.dateOfEnquiry = dateOfEnquiry;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "ProductEnquiryRequestDTO [clientName=" + clientName + ", clientMobile=" + clientMobile
				+ ", dateOfEnquiry=" + dateOfEnquiry + ", productId=" + productId + "]";
	}

}

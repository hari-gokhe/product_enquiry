package com.productenquiry.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productenquiry.entity.Product;
import com.productenquiry.service.ProductService;

import RequestDTO.ProductRequestDTO;

@RestController
@RequestMapping("/product")
public class ProductController {
	
    Logger logger = LoggerFactory.getLogger(ProductController.class);


    @Autowired
	private ProductService productService; 
	
	
	@GetMapping("/products")
	public ResponseEntity<?>  getProduct(){
		logger.info("ProductController.getProduct started");
		try {
			List<Product> products = productService.porudctList();
			logger.info("Product found: {}", products);
			return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		} catch(Exception e){
			logger.error("Error occurred at : {}", e.getMessage());
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/addProduct")
	public ResponseEntity<String> addProduct(@RequestBody ProductRequestDTO productReq) {
		logger.info("ProductController.addProduct started");
		try {
			Product product  = new Product();
			product.setProductName(productReq.getProductName());
			product.setIsActive(productReq.getIsActive());		
			Product newProduct = productService.addProduct(product);
			logger.info("new product added : {}", newProduct);
			return new ResponseEntity<String>("product added successfully",HttpStatus.CREATED);
		} catch(Exception e){
			logger.error("Error occurred at : {}", e.getMessage());
			return new ResponseEntity<String>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
}

package com.productenquiry.controller.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.productenquiry.entity.ProductEnquiry;

@Repository
public interface ProductEnquiryRepository extends JpaRepository<ProductEnquiry, Long> {

	@Query(value = "select s.* from PRODUCT_ENQUIRY  s where s.product_id =:productId and s.DATE_OFENQUIRY =:date", nativeQuery = true)
	List<ProductEnquiry> findByProductEnquiryList(@Param("productId") Long productId, @Param("date") LocalDate date);
}

package com.productenquiry.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.productenquiry.entity.Product;
import com.productenquiry.entity.ProductEnquiry;
import com.productenquiry.service.ProductEnquiryService;
import com.productenquiry.service.ProductService;

import RequestDTO.ProductEnquiryRequestDTO;

@RestController
@RequestMapping("productEnquiry")
public class ProductEnquiryController {

	Logger logger = LoggerFactory.getLogger(ProductEnquiryController.class);

	@Autowired
	private ProductService productService;

	@Autowired
	private ProductEnquiryService productEnquiryService;

	@PostMapping("/addProductEnquiry")
	public ResponseEntity<String> addProductEnquiry(@RequestBody ProductEnquiryRequestDTO productEnquiryReq) {
		logger.info("ProductEnquiryController.addProductEnquiry started");
		try {
			Product product = productService.getProductById(productEnquiryReq.getProductId());
			ProductEnquiry productEnquiry = new ProductEnquiry();
			productEnquiry.setClientName(productEnquiryReq.getClientName());
			productEnquiry.setClientMobile(productEnquiryReq.getClientMobile());
			productEnquiry.setDateOfEnquiry(productEnquiryReq.getDateOfEnquiry());
			productEnquiry.setProduct(product);
			ProductEnquiry newProductEnquiry = productEnquiryService.addProductEnquiry(productEnquiry);
			logger.info("new product enquiry added : {}", newProductEnquiry);
			return new ResponseEntity<String>("product enquiry added successfully", HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error occurred at : {}", e.getMessage());
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping("/getProductEnquiryByProductAndDate")
	public ResponseEntity searchEnquiry(@RequestBody ProductEnquiryRequestDTO productEnquiryReq) {
		logger.info("ProductEnquiryController.searchEnquiry started with ProductEnquiryRequestDTO: {}",
				productEnquiryReq);
		try {
			List<ProductEnquiry> productEnquiryList = productEnquiryService
					.getListEnquiry(productEnquiryReq.getProductId().longValue(), productEnquiryReq.getDateOfEnquiry());
			logger.info("found result from search product enquiry : {}", productEnquiryList);
			return new ResponseEntity<List<ProductEnquiry>>(productEnquiryList, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error occurred at : {}", e.getMessage());
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}

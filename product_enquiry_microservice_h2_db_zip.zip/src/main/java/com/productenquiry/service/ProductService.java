package com.productenquiry.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productenquiry.controller.repository.ProductRepository;
import com.productenquiry.entity.Product;

@Service
public class ProductService implements ProductServiceInterface {

	Logger logger = LoggerFactory.getLogger(ProductService.class);

	@Autowired
	private ProductRepository productRepo;

	@Override
	public Product addProduct(Product product) {
		logger.info("ProductService.addProduct with Product: {}", product);
		return productRepo.save(product);
	}

	@Override
	public List<Product> porudctList() {
		logger.info("ProductService.porudctList started");
		return productRepo.findAll();
	}

	public Product getProductById(Integer productId) {
		logger.info("ProductService.getProductById started with productId: ", productId);
		return productRepo.findById(productId.longValue()).orElse(null);
	}

}

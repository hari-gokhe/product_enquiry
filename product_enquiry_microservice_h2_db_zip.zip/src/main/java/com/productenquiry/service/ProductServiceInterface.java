package com.productenquiry.service;

import java.util.List;
import java.util.Optional;

import com.productenquiry.entity.Product;

public interface ProductServiceInterface {
	public Product addProduct(Product product);

	public List<Product> porudctList();

	public Product getProductById(Integer productId);
}

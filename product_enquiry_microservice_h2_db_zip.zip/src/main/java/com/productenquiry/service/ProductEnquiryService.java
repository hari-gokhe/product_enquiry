package com.productenquiry.service;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.productenquiry.controller.repository.ProductEnquiryRepository;
import com.productenquiry.entity.ProductEnquiry;

@Service
public class ProductEnquiryService implements ProductEnquiryInterface {

	Logger logger = LoggerFactory.getLogger(ProductEnquiryService.class);

	@Autowired
	private ProductEnquiryRepository productEnquiryRepo;

	@Override
	public ProductEnquiry addProductEnquiry(ProductEnquiry productEnquiry) {
		logger.info("ProductEnquiryService.addProductEnquiry with ProductEnquiry: {}", productEnquiry);
		return productEnquiryRepo.save(productEnquiry);
	}

	@Override
	public List<ProductEnquiry> getListEnquiry(Long productId, LocalDate date) {
		logger.info("search in ProductEnquiryService.getListEnquiry with product ID: {} on date: {}", productId, date);
		return productEnquiryRepo.findByProductEnquiryList(productId, date);
	}

}

package com.productenquiry.service;

import java.time.LocalDate;
import java.util.List;

import com.productenquiry.entity.Product;
import com.productenquiry.entity.ProductEnquiry;

public interface ProductEnquiryInterface {

	public ProductEnquiry addProductEnquiry(ProductEnquiry productEnquiry);

	public List<ProductEnquiry> getListEnquiry(Long productId, LocalDate date);

}

package com.productenquiry.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Product_Enquiry")
public class ProductEnquiry {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer enquiryId;
	private String clientName;
	private String clientMobile;
	@Column(name = "dateOfenquiry")
	private LocalDate dateOfEnquiry;

	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;

	public ProductEnquiry(Integer enquiryId, String clientName, String clientMobile, LocalDate dateOfEnquiry,
			Product product) {
		super();
		this.enquiryId = enquiryId;
		this.clientName = clientName;
		this.clientMobile = clientMobile;
		this.dateOfEnquiry = dateOfEnquiry;
		this.product = product;
	}

	public ProductEnquiry() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getClientMobile() {
		return clientMobile;
	}

	public void setClientMobile(String clientMobile) {
		this.clientMobile = clientMobile;
	}

	public LocalDate getDateOfEnquiry() {
		return dateOfEnquiry;
	}

	public void setDateOfEnquiry(LocalDate dateOfEnquiry) {
		this.dateOfEnquiry = dateOfEnquiry;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductEnquiry [enquiryId=" + enquiryId + ", clientName=" + clientName + ", clientMobile="
				+ clientMobile + ", dateOfEnquiry=" + dateOfEnquiry + ", product=" + product + "]";
	}

}

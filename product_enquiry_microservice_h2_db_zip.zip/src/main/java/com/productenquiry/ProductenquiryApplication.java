package com.productenquiry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductenquiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductenquiryApplication.class, args);
	}

}

package com.service.Test;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.productenquiry.controller.repository.ProductEnquiryRepository;
import com.productenquiry.controller.repository.ProductRepository;
import com.productenquiry.entity.Product;
import com.productenquiry.entity.ProductEnquiry;
import com.productenquiry.service.ProductEnquiryService;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
public class ProductEnquiryTest {

	@Mock
	private ProductRepository productRepo;

	@Mock
	private ProductEnquiryRepository productEnquiryRepo;

	@Mock
	private ProductEnquiryService productEnquiryService;

	@Test
	public void RegisterEnquiryTest() {
		LocalDate enquirydate = LocalDate.of(2023, 5, 6);
		Integer productId = 1;

		ProductEnquiry productEnquiry1 = new ProductEnquiry();
		productEnquiry1.setClientName("Akash");
		productEnquiry1.setClientMobile("9988776655");
		productEnquiry1.setDateOfEnquiry(enquirydate);

		Product product1 = new Product();
		product1.setIsActive(true);
		product1.setProductName("Mobile");

		productEnquiry1.setProduct(product1);

		ProductEnquiry productEnquiry2 = new ProductEnquiry();
		productEnquiry2.setClientName("vijay");
		productEnquiry2.setClientMobile("8877996655");
		productEnquiry2.setDateOfEnquiry(enquirydate);

		Product product2 = new Product();
		product2.setIsActive(true);
		product2.setProductName("Laptop");

		productEnquiry2.setProduct(product2);

		List<ProductEnquiry> mockEnquiries = new ArrayList<>();
		mockEnquiries.add(productEnquiry1);
		mockEnquiries.add(productEnquiry2);

		when(productEnquiryRepo.findByProductEnquiryList(productId.longValue(), enquirydate)).thenReturn(mockEnquiries);

		List<ProductEnquiry> result = productEnquiryService.getListEnquiry(productId.longValue(), enquirydate);

		assertEquals(2, result.size());
		assertEquals(productEnquiry1, result.get(0));
		assertEquals(productEnquiry2, result.get(1));
	}
}
